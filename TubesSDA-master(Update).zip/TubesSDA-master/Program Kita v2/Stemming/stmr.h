
#define TRUE 1
#define FALSE 0

int stem(char *p, int index, int position);
