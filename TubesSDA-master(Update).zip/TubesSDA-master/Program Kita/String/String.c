#include<stdlib.h>
#include<stdio.h>
#include<String.h>
#include"string.h"

//String createString (int initialSize) {
//	/* Deskripsi Modul :  */
//	String s;
//	int i;
//	
//	s.size = initialSize;
//	s.used = 0;
//	s.string = (char*)malloc(s.size * sizeof(char));
//	
//	for(i=0; i<s.size; i++)
//		s.string[i] = '\0'; // PENTING BANGET ASELI wkwk
//		
//	return s;
//}
