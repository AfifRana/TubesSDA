#ifndef count_h
#define count_h
#define Nil NULL

/*  */

/* Modul */
void insertInt (int number, Count *c, int fileIndex);
int getCount (adr countNode, int fileIndex);

#endif
