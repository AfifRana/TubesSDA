#ifndef include_h
#define include_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include"count/count.h"
#include"tree/tree.h"
#include"string/string.h"
#endif
