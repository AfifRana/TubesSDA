//author: cahya, reyhan, manda

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "tree.h"
#include "tree.c"

typedef struct{
	Tree basicWords;
	Tree stopword;
} StemTree;


